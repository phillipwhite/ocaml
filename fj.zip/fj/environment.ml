open Syntax
type 'a t = (Syntax.field * 'a) list

exception Not_bound

let objcon = {sfields=[]; dfields=[];
	     body={sup=[]; init=[]}}

let init_ctable = {cname="Object"; super_name=""; fdec=[];
	      con=objcon; mdecs=[] }::[]

let empty = []
let extend x v env = (x,v)::env

let rec lookup x env = 
  try List.assoc x env with Not_found -> raise Not_bound

let rec map f = function
    [] -> []
  | (id, v)::rest -> (id, f v) :: map f rest

let rec fold_right f env a = 
  match env with
      [] -> a
    | (_, v)::rest -> f v (fold_right f rest a)

let rec append l1 l2 = 
  match l1 with
      [] -> l2
    | x :: rest -> x :: (append rest l2);;

let rec reverse = function
[] ->[]
  | x::rest -> append (reverse rest) [x];;



let rec getSuperClass cl = function
  [] -> raise Not_bound
  | x::rest  -> if  cl.super_name = x.cname then x
    else getSuperClass cl rest

let rec getClass cname = function
[] -> raise Not_bound
  | x::rest -> if cname = x.cname then x
  else getClass cname rest

let rec getFields cl ctable =
  if cl.cname = "Object" then []
  else append cl.fdec (getFields (getSuperClass cl ctable) ctable)

let rec getMethods cl ctable =
  if cl.cname = "Object" then []
  else append cl.mdecs (getMethods (getSuperClass cl ctable) ctable)

let rec flookup cl fname ctable =
  try List.assoc fname (getFields cl ctable) with Not_found
      -> raise Not_bound

let  mlookup cl mname ctable =
  let methods = getMethods cl ctable in
  let rec lkup mname methods =
    match methods with 
	[] -> raise Not_bound
      | x::rest -> 
	let hdm = List.hd methods in
	if mname = hdm.mname then
	  hdm
	else
	  lkup mname rest
  in lkup mname methods
