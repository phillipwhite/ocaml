open Syntax
open Eval

let cdr = function [] -> [] | _ :: rest -> rest;;

(* let rec reverse = function [] -> [] | x :: rest -> append ( reverse rest) [x];; *)

let rec read_eval_print ctable  =
  print_string "# ";
  flush stdout;
  let decl = Parser.toplevel Lexer.main (Lexing.from_channel stdin) in
  let (newct, v) = eval_decl ctable [] [] decl in
  Printf.printf "val  = ";
  pp_val v;
  print_newline();
  read_eval_print newct

let _ = read_eval_print Environment.init_ctable
